import React from 'react'
import '../styles/About.css'



function About() {
  return (
    <div className='about_container'>
      <span>"A JavaScript library for building user interfaces"</span>
      <span>- REACT -</span>
    </div>
  )
}

export default About